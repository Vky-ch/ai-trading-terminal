import "./globals.css";
export const metadata={title:"AI Trading Terminal",description:"Realtime trading analytics",manifest:"/manifest.json"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html><body>{children}</body></html>}
