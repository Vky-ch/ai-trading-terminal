"use client";
import {useEffect,useState} from "react";

const API=process.env.NEXT_PUBLIC_API_URL||"http://127.0.0.1:8000";
const WS=API.replace(/^http/,"ws")+"/ws";

export default function Home(){
 const [signals,setSignals]=useState<any[]>([]);
 const [prices,setPrices]=useState<any>({});
 const [online,setOnline]=useState(false);
 useEffect(()=>{
   const ws=new WebSocket(WS);
   ws.onopen=()=>setOnline(true); ws.onclose=()=>setOnline(false);
   ws.onmessage=e=>{const m=JSON.parse(e.data);
     if(m.type==="snapshot"){setSignals(m.signals||[]);setPrices(m.prices||{});}
     if(m.type==="tick")setPrices((p:any)=>({...p,[m.symbol]:{price:m.price,timestamp:m.timestamp}}));
     if(m.type==="signal")setSignals((s:any[])=>{const a=s.filter(x=>x.symbol!==m.data.symbol);return [...a,m.data]});
   };
   return()=>ws.close();
 },[]);
 return <main>
  <header><div><h1>AI Trading Terminal</h1><p>Realtime market intelligence</p></div><span className={online?"dot on":"dot"}>{online?"LIVE":"OFFLINE"}</span></header>
  <section className="watch">{Object.entries(prices).map(([s,v]:any)=><div className="ticker" key={s}><b>{s}</b><strong>{Number(v.price).toLocaleString(undefined,{maximumFractionDigits:6})}</strong></div>)}</section>
  <div className="grid">{signals.map((x:any)=><article className="card" key={x.symbol}>
    <div className="top"><h2>{x.symbol}</h2><span className={x.direction==="BUY"?"buy":x.direction==="SELL"?"sell":"wait"}>{x.direction}</span></div>
    <div className="score">Signal strength <b>{x.score}%</b></div>
    {x.entry&&<div className="levels"><div><small>ENTRY</small><b>{fmt(x.entry)}</b></div><div><small>SL</small><b>{fmt(x.stop_loss)}</b></div><div><small>TP1</small><b>{fmt(x.tp1)}</b></div><div><small>TP2</small><b>{fmt(x.tp2)}</b></div><div><small>TP3</small><b>{fmt(x.tp3)}</b></div></div>}
    <p className="risk">News risk: <b>{x.news_risk||"LOW"}</b></p>
    <div className="tf">{(x.timeframes||[]).map((t:any)=><span key={t.tf}>{t.tf}: {t.trend}</span>)}</div>
  </article>)}</div>
  <footer>Analytics only. No guarantee of profit. Validate signals before trading.</footer>
 </main>
}
function fmt(n:any){return n==null?"—":Number(n).toLocaleString(undefined,{maximumFractionDigits:6})}
