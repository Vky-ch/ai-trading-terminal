# AI Trading Terminal — Mobile Ready

A full-stack PWA trading dashboard with:
- realtime crypto prices from Binance WebSocket
- optional Twelve Data adapter for forex/metals
- multi-timeframe technical signal engine
- ATR stop-loss / take-profit levels
- mobile-first responsive UI
- installable as a phone home-screen app

## Important
No market feed can honestly be guaranteed "zero-lag". This app uses WebSockets and reports provider timestamps/connection state instead.

## Fastest way to run on Android

### Option A — Termux
1. Install Termux from F-Droid.
2. Install Node.js and Python:
   `pkg update && pkg install nodejs python git`
3. Unzip this project.
4. Run backend:
   `cd backend && pip install -r requirements.txt && uvicorn main:app --host 0.0.0.0 --port 8000`
5. In another Termux session:
   `cd frontend && npm install && npm run dev -- --host 0.0.0.0`
6. Open Chrome on the phone at:
   `http://127.0.0.1:3000`
7. Use Chrome menu → Add to Home screen.

### Option B — Deploy it
The frontend can be deployed to Vercel/Netlify and the backend to Render/Railway/Fly.io. Set `NEXT_PUBLIC_API_URL` to the backend URL.

## Data
Crypto works without an API key through Binance public WebSocket market streams.
Forex/metals require a provider API key; the included Twelve Data adapter is ready for that.

Create `backend/.env` from `.env.example`.

This is an analytics/education application, not an execution or profit-guarantee system. Backtest before risking money.
