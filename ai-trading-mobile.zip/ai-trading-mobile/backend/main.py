import asyncio, json, os, time
from collections import defaultdict, deque
from datetime import datetime, timezone
from typing import Dict, List

import httpx
import numpy as np
import pandas as pd
import websockets
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    TWELVE_DATA_API_KEY: str = ""
    CORS_ORIGINS: str = "http://localhost:3000,http://127.0.0.1:3000"

settings = Settings()

app = FastAPI(title="AI Trading Terminal")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in settings.CORS_ORIGINS.split(",")],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

clients = set()
prices = {}
candles = defaultdict(lambda: defaultdict(lambda: deque(maxlen=500)))
last_signal = {}
last_news = {"risk": "LOW", "message": "News filter not connected; technical-only mode."}

SYMBOLS = {
    "BTCUSDT": "BTC/USDT",
    "ETHUSDT": "ETH/USDT",
    "BNBUSDT": "BNB/USDT",
    "SOLUSDT": "SOL/USDT",
}
TIMEFRAMES = ["1m", "5m", "15m", "1h", "4h"]

def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()

def rsi(s, n=14):
    d=s.diff()
    g=d.clip(lower=0)
    l=-d.clip(upper=0)
    ag=g.ewm(alpha=1/n, adjust=False).mean()
    al=l.ewm(alpha=1/n, adjust=False).mean()
    rs=ag/(al.replace(0, np.nan))
    return (100-100/(1+rs)).fillna(50)

def atr(df, n=14):
    pc=df.close.shift(1)
    tr=pd.concat([df.high-df.low,(df.high-pc).abs(),(df.low-pc).abs()],axis=1).max(axis=1)
    return tr.ewm(alpha=1/n, adjust=False).mean()

def macd(s):
    m=ema(s,12)-ema(s,26)
    sig=ema(m,9)
    return m,sig,m-sig

def timeframe_score(symbol, tf):
    rows=list(candles[symbol][tf])
    if len(rows)<60: return 0, "INSUFFICIENT", None
    df=pd.DataFrame(rows)
    c=df.close
    e20,e50,e200=ema(c,20),ema(c,50),ema(c, min(200,len(c)-1))
    rv=float(rsi(c).iloc[-1])
    _,_,hist=macd(c)
    score=0
    if e20.iloc[-1]>e50.iloc[-1]: score+=25
    else: score-=25
    if c.iloc[-1]>e200.iloc[-1]: score+=20
    else: score-=20
    if hist.iloc[-1]>0: score+=20
    else: score-=20
    if 50<=rv<=70: score+=15
    elif 30<=rv<50: score-=15
    return score, ("BULLISH" if score>15 else "BEARISH" if score<-15 else "NEUTRAL"), float(atr(df).iloc[-1])

def make_signal(symbol):
    details=[]
    total=0
    for tf,w in [("4h",0.25),("1h",0.25),("15m",0.30),("5m",0.20)]:
        s,t,a=timeframe_score(symbol,tf)
        total += s*w
        details.append({"tf":tf,"score":round(s,1),"trend":t})
    direction="BUY" if total>=35 else "SELL" if total<=-35 else "WAIT"
    rows=list(candles[symbol]["5m"])
    if len(rows)<60:
        return {"symbol":symbol,"direction":"WAIT","score":0,"reason":"Waiting for enough candles."}
    df=pd.DataFrame(rows); price=float(df.close.iloc[-1]); a=float(atr(df).iloc[-1])
    if direction=="BUY":
        sl=price-1.5*a; tp1=price+1.5*a; tp2=price+3*a; tp3=price+4.5*a
    elif direction=="SELL":
        sl=price+1.5*a; tp1=price-1.5*a; tp2=price-3*a; tp3=price-4.5*a
    else:
        sl=tp1=tp2=tp3=None
    return {
        "symbol":symbol,"direction":direction,
        "score":round(abs(total),1),"entry":price,
        "stop_loss":sl,"tp1":tp1,"tp2":tp2,"tp3":tp3,
        "news_risk":last_news["risk"],"timeframes":details,
        "updated":datetime.now(timezone.utc).isoformat()
    }

def add_trade(symbol, price, ts):
    # Build 1m candle from incoming trade stream.
    bucket=int(ts//60000)*60000
    arr=candles[symbol]["1m"]
    if not arr or arr[-1]["time"]!=bucket:
        arr.append({"time":bucket,"open":price,"high":price,"low":price,"close":price})
    else:
        x=arr[-1]; x["high"]=max(x["high"],price); x["low"]=min(x["low"],price); x["close"]=price
    # Resample 1m candles to other timeframes.
    base=list(arr)
    if len(base)>=5:
        df=pd.DataFrame(base).set_index(pd.to_datetime([x["time"] for x in base],unit="ms"))
        for tf,rule in [("5m","5min"),("15m","15min"),("1h","1h"),("4h","4h")]:
            r=df.resample(rule).agg({"open":"first","high":"max","low":"min","close":"last"}).dropna()
            candles[symbol][tf].clear()
            for idx,row in r.tail(500).iterrows():
                candles[symbol][tf].append({"time":int(idx.timestamp()*1000),"open":float(row.open),"high":float(row.high),"low":float(row.low),"close":float(row.close)})
    prices[symbol]={"price":price,"timestamp":ts}

async def broadcast(msg):
    dead=[]
    for ws in list(clients):
        try: await ws.send_json(msg)
        except: dead.append(ws)
    for ws in dead: clients.discard(ws)

async def binance_loop():
    streams="/".join(f"{s.lower()}@trade" for s in SYMBOLS)
    url=f"wss://stream.binance.com:9443/stream?streams={streams}"
    while True:
        try:
            async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:
                async for raw in ws:
                    p=json.loads(raw)["data"]
                    symbol=p["s"]; price=float(p["p"]); ts=int(p["T"])
                    add_trade(symbol,price,ts)
                    await broadcast({"type":"tick","symbol":symbol,"price":price,"timestamp":ts})
        except Exception as e:
            await asyncio.sleep(2)

async def signal_loop():
    while True:
        for s in SYMBOLS:
            sig=make_signal(s)
            last_signal[s]=sig
            await broadcast({"type":"signal","data":sig})
        await asyncio.sleep(5)

@app.on_event("startup")
async def startup():
    asyncio.create_task(binance_loop())
    asyncio.create_task(signal_loop())

@app.get("/api/status")
async def status():
    return {"status":"ok","symbols":list(SYMBOLS),"feed":"Binance WebSocket","news":last_news}

@app.get("/api/signals")
async def signals():
    return list(last_signal.values())

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept(); clients.add(ws)
    try:
        await ws.send_json({"type":"snapshot","signals":list(last_signal.values()),"prices":prices})
        while True: await ws.receive_text()
    except WebSocketDisconnect:
        clients.discard(ws)
    except Exception:
        clients.discard(ws)
